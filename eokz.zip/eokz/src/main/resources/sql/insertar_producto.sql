-- Insertar un producto
INSERT INTO Productos (codigo, descripcion, material, color, precio, stock)
VALUES (:codigo, :descripcion, :material, :color, :precio, :stock);